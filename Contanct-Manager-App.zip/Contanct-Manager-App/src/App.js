import './App.css';
import React from 'react';
import NavBar from './Components/NavBar/NavBar';
import { Routes, Route, Navigate } from 'react-router-dom';
import ContactList from './Components/Contacts/ContactList/ContactList';
import AddContact from './Components/Contacts/AddContact/AddContact';
import ViewContact from './Components/Contacts/ViewContact/ViewContact';
import UpdateContact from './Components/Contacts/UpdateContact/UpdateContact';


function App() {
  return (
    <React.Fragment>
      <NavBar/>
      <Routes>
        <Route path='/' element={<Navigate to ={'/contacts/list'}/>}></Route>
        <Route path='/contacts/list' element={<ContactList/>}></Route>
        <Route path='/contacts/add' element={<AddContact/>}></Route>
        <Route path='/contacts/view/:contactId' element={<ViewContact/>}></Route>
        <Route path='/contacts/update/:contactId' element={<UpdateContact/>}></Route>
      </Routes>
    </React.Fragment>
  );
}

export default App;
